---
title: git_learn
date: 2021-09-09 16:41:08
tags:
categories:
password:
abstract:
message:
---

![image-20210909164119386](image-20210909164119386.png "dsfsdf")

![image-20210909165936257](image-20210909165936257.png)

gitlab 是origin main而不是master,绝了！

git reset --hard 

[error: src refspec master does not match any. 错误处理办法 - JeremyLee87 - 博客园 (cnblogs.com)](https://www.cnblogs.com/jeremylee/p/5715289.html)

[Git 多人协作开发流程 - SegmentFault 思否](https://segmentfault.com/a/1190000013059664)

![image-20210910093541121](image-20210910093541121.png)

