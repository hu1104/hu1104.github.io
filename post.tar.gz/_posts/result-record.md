---
title: result_record
date: 2021-07-12 17:05:19
tags:
  - 加密
password: asdfqwer
abstract: test结果记录
message: st结果记录2
---





### 重复标记

+ 同一个对象，被同时标记为impus和cluster
  + ![图片](result-record.assets/single_cluster.png) # 已经将红框（代表impus)移到图中位置，原与cluster重合

+ 同时被标记single+2*cluster
  + ![图片](result-record.assets/1single2cluster.png)![图片](result-record.assets/1s2csplit-1626242245110.png)# 红框代表single,蓝框代表cluster，可以看到三个标注框

+ 同时标注single+cluster

  + ![图片](result-record.assets/single_cluster2.png)![图片](result-record.assets/single_cluster_split.png)# single是蓝框，cluster是红框

    

+ 一大堆标注结果
  + ![图片](result-record.assets/conf.png)# 总共6个single和1个cluster：蓝色代表single,红色代表cluster
    + ![s1](result-record.assets/s1.png) ![s2](result-record.assets/s2-1626243108808.png) ![s3](result-record.assets/s3.png) ![s4](result-record.assets/s4.png) ![s5](result-record.assets/s5.png) ![s6](result-record.assets/s6-1626243203957.png) ![c1](result-record.assets/c1-1626243218929.png) 
  + ![conf2](result-record.assets/conf2.png) 

+ cluster 相对标准
  + ![image-20210714150039087](result-record.assets/image-20210714150039087.png) # 这种就只有一个cluster



### 正常的cluster

+ ![image-20210714153111446](result-record.assets/image-20210714153111446.png) 







修改记录：

single2cluster

+ ![image-20210719111051603](result-record.assets/image-20210719111051603.png)

![图片](result-record.assets/single2cluster.png) 由single改为cluster



+ ![image-20210719111714890](result-record.assets/image-20210719111714890.png) 

  ![image-20210719111739527](result-record.assets/image-20210719111739527.png) 

+ ![image-20210719112800990](result-record.assets/image-20210719112800990.png) 

  ![image-20210719112819925](result-record.assets/image-20210719112819925.png) 

+ ![image-20210719112950756](result-record.assets/image-20210719112950756.png) 

   ![image-20210719113004108](result-record.assets/image-20210719113004108.png) 

+ ![image-20210719113522216](result-record.assets/image-20210719113522216.png) 以及之前的几张需要讨论![image-20210719113543384](result-record.assets/image-20210719113543384.png) ![image-20210719131056102](result-record.assets/image-20210719131056102.png) 

+ ![image-20210719134355469](result-record.assets/image-20210719134355469.png)

  ![image-20210719134409308](result-record.assets/image-20210719134409308.png) 上面那个修改

+ ![image-20210719153213029](result-record.assets/image-20210719153213029.png)  

  ![image-20210719153249901](result-record.assets/image-20210719153249901.png) 





# 训练结果



训练集5800张，测试集张向银标注的0文件夹

![image-20210720135750511](result-record/image-20210720135750511.png)





exp14 15:18

![image-20210721154225233](result-record/image-20210721154225233.png)



exp16 17:03

训练结果

![image-20210721171447814](result-record/image-20210721171447814.png)

测试

![image-20210721172015766](result-record/image-20210721172015766.png)





#结果比对

+ ![image-20210727141821831](result-record/image-20210727141821831.png) ![image-20210727141842480](result-record/image-20210727141842480.png) ![image-20210727141904386](result-record/image-20210727141904386.png)  正确

+ ![image-20210727142000715](result-record/image-20210727142000715.png) ![image-20210727142009849](result-record/image-20210727142009849.png) ![image-20210727142020843](result-record/image-20210727142020843.png) 错误

+ ![image-20210727142509913](result-record/image-20210727142509913.png) ![image-20210727142521659](result-record/image-20210727142521659.png) ![image-20210727142531425](result-record/image-20210727142531425.png) 未识别
+ ![image-20210727142643481](result-record/image-20210727142643481.png) ![image-20210727142654179](result-record/image-20210727142654179.png) ![image-20210727142702976](result-record/image-20210727142702976.png) 错误
+ ![image-20210727142816561](result-record/image-20210727142816561.png) ![image-20210727142835289](result-record/image-20210727142835289.png) ![image-20210727142842722](result-record/image-20210727142842722.png) 标记？
+ ![image-20210727142920025](result-record/image-20210727142920025.png) ![image-20210727142928012](result-record/image-20210727142928012.png) ![image-20210727142935239](result-record/image-20210727142935239.png) 错误
+ ![image-20210727143051707](result-record/image-20210727143051707.png) ![image-20210727143057976](result-record/image-20210727143057976.png) ![image-20210727143103953](result-record/image-20210727143103953.png) 
+ ![image-20210727143227363](result-record/image-20210727143227363.png) ![image-20210727143234610](result-record/image-20210727143234610.png) ![image-20210727143243488](result-record/image-20210727143243488.png) 
+ ![image-20210727143312592](result-record/image-20210727143312592.png) ![image-20210727143320679](result-record/image-20210727143320679.png)  ![image-20210727143336271](result-record/image-20210727143336271.png) 
+ ![image-20210727143406421](result-record/image-20210727143406421.png) ![image-20210727143412473](result-record/image-20210727143412473.png) ![image-20210727143417497](result-record/image-20210727143417497.png) 
+ ![image-20210727144615165](result-record/image-20210727144615165.png) ![image-20210727144621646](result-record/image-20210727144621646.png) ![image-20210727144628119](result-record/image-20210727144628119.png) 
+ ![image-20210727144648183](result-record/image-20210727144648183.png) ![image-20210727144654247](result-record/image-20210727144654247.png) ![image-20210727144701358](result-record/image-20210727144701358.png) 
+ ![image-20210727144739278](result-record/image-20210727144739278.png) ![image-20210727144813215](result-record/image-20210727144813215.png) ![image-20210727144829894](result-record/image-20210727144829894.png) 
+ ![image-20210727144924614](result-record/image-20210727144924614.png) ![image-20210727144931349](result-record/image-20210727144931349.png) ![image-20210727144938606](result-record/image-20210727144938606.png) 
+ ![image-20210727145016958](result-record/image-20210727145016958.png) ![image-20210727145026498](result-record/image-20210727145026498.png) ![image-20210727145035036](result-record/image-20210727145035036.png) 上为impus,下为cluster
+ ![image-20210727145204532](result-record/image-20210727145204532.png) ![image-20210727145210768](result-record/image-20210727145210768.png) ![image-20210727145217220](result-record/image-20210727145217220.png) 
+ ![image-20210727145437390](result-record/image-20210727145437390.png) ![image-20210727145446594](result-record/image-20210727145446594.png)  ![image-20210727145453797](result-record/image-20210727145453797.png) 
+ ![image-20210727145520500](result-record/image-20210727145520500.png) ![image-20210727145526099](result-record/image-20210727145526099.png) ![image-20210727145541670](result-record/image-20210727145541670.png) 
+ ![image-20210727145638436](result-record/image-20210727145638436.png) ![image-20210727145646165](result-record/image-20210727145646165.png) ![image-20210727145653057](result-record/image-20210727145653057.png) ![image-20210727145708706](result-record/image-20210727145708706.png) ![image-20210727145715475](result-record/image-20210727145715475.png) ![image-20210727145729701](result-record/image-20210727145729701.png) ![image-20210727145735379](result-record/image-20210727145735379.png) ![image-20210727145758372](result-record/image-20210727145758372.png) ![image-20210727145806129](result-record/image-20210727145806129.png) 

## 后续图太复杂，切换保存的txt文件

+ ![image-20210727152433255](result-record/image-20210727152433255.png)  ![image-20210727152509191](result-record/image-20210727152509191.png) ![image-20210727152520504](result-record/image-20210727152520504.png) 少标一个小物体，多标一个single
+ ![image-20210727152633062](result-record/image-20210727152633062.png) ![image-20210727152643087](result-record/image-20210727152643087.png) ![image-20210727152652184](result-record/image-20210727152652184.png) 程序认定cluster，标记为两个single
+ ![image-20210727152752894](result-record/image-20210727152752894.png) ![image-20210727152800590](result-record/image-20210727152800590.png) ![image-20210727152806521](result-record/image-20210727152806521.png) 外圈结果为cluster，内部还有single
+ ![image-20210727153021316](result-record/image-20210727153021316.png) ![image-20210727153033334](result-record/image-20210727153033334.png)  ![image-20210727153051447](result-record/image-20210727153051447.png) 
+ ![image-20210727153105896](result-record/image-20210727153105896.png) ![image-20210727153113209](result-record/image-20210727153113209.png) 
+ ![image-20210727153154403](result-record/image-20210727153154403.png) ![image-20210727153202138](result-record/image-20210727153202138.png)  ![image-20210727153212175](result-record/image-20210727153212175.png)
+ ![image-20210727153401582](result-record/image-20210727153401582.png) ![image-20210727153408876](result-record/image-20210727153408876.png) impus被识别成single
+ ![image-20210727153803798](result-record/image-20210727153803798.png) ![image-20210727153857246](result-record/image-20210727153857246.png) ![image-20210727153905180](result-record/image-20210727153905180.png) 右边的出现single和cluster重复hex o
+ ![image-20210727154331021](result-record/image-20210727154331021.png)![image-20210727154401113](result-record/image-20210727154401113.png) 



# mobilenet 



+ ![image-20210729090659819](result-record/image-20210729090659819.png) 