---
title: mmdetection
date: 2021-08-30 15:33:17
tags:
categories:
password:
abstract:
message:
---





# 参考资料

[MMDetection 2.5 目标检测（3）：配置修改 - 简书 (jianshu.com)](https://www.jianshu.com/p/38f4525246e1)

[mmdetection源码分析faster-rcnn，读懂mmdetection - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/137454940)

[将自己数据集转化成voc数据集格式并用mmdetection训练 - 简书 (jianshu.com)](https://www.jianshu.com/p/924db4d52213)

[(29条消息) （详细教程）mmdetection训练自己的模型，测试，评估_若风的博客-CSDN博客](https://blog.csdn.net/qq_33897832/article/details/103995636)

[(29条消息) 【MMDetection-学习记录】 训练自己的VOC数据集_乐亦亦乐的博客-CSDN博客](https://blog.csdn.net/qq_41251963/article/details/112940253)

[MMDetection v2.0 训练自己的数据集 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/162730118)

[mmdetection 模型训练](https://www.aiuai.cn/aifarm1218.html)

[mmdetection源码解读（一） - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/128697076)

